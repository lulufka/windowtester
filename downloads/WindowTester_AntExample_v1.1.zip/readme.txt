WindowTester Pro - Ant example
==============================

This is a small example that shows how to run WindowTester Pro UI tests using Ant.
The Eclipse SDK Examples plugin acts as the plugin that should be tested.

Currently only plugins of a RCP application can be tested with this method.
Testing a complete RCP application can be done with Maven/Tycho.

Supported platforms: Win32, Win64 and Linux x86 GTK
Eclipse platform: 3.7.2

This example can easily be adapted for other platforms and Eclipse versions.

Requirements:

-Apache Ant:
  Download from: http://ant.apache.org/

-Eclipse SDK 3.7.2
  Win32		-> http://www.eclipse.org/downloads/download.php?file=/technology/epp/downloads/release/indigo/SR2/eclipse-rcp-indigo-SR2-win32.zip
  Win64		-> http://www.eclipse.org/downloads/download.php?file=/technology/epp/downloads/release/indigo/SR2/eclipse-rcp-indigo-SR2-win32-x86_64.zip
  Linux32	-> http://www.eclipse.org/downloads/download.php?file=/technology/epp/downloads/release/indigo/SR2/eclipse-rcp-indigo-SR2-linux-gtk.tar.gz

-Eclipse Test Framework
  http://archive.eclipse.org/eclipse/downloads/drops/R-3.7.2-201202080800/download.php?dropFile=eclipse-test-framework-3.7.2.zip

-Eclipse SDK Examples
  http://archive.eclipse.org/eclipse/downloads/drops/R-3.7.2-201202080800/download.php?dropFile=org.eclipse.sdk.examples-3.7.2.zip

-WindowTester Pro Repo Zip
  -> WindowTesterRepo-6.1.0-CommunityFixes.zip (included)
    -> Important: This is not an official release and should not be used in production environments without proper testing.
    It's included because the official WindowTester P2 repository does not yet contain a fix for a problem with SWT Slider widgets on Linux systems.

-UI Test plugin
  -> com.windowtester.example.swtcontrols_test_1.0.0.201302270112.jar (included)


Setup
-----
1. Install Ant (if it's not already installed)
2. Place all downloaded Eclipse zip files in the same directory as the Ant scripts
3. Run the setup Ant script (only needs to be run once):
   Linux32:	setupLinux32.sh
   Win32:	setupWin32.bat
   Win64:	setupWin64.bat

Run tests
---------
Run the Ant script
   If JAVA_HOME/ANT_HOME are not set on your system, then you need to adapt the batch files accordingly.
   Linux32:	runLinux32.sh
   Win32:	runWin32.bat
   Win64:	runWin64.bat


What does the setup.xml script do?
----------------------------------
1. Unpacks Eclipse SDK to directory "setup-eclipse"
2. Converts the Window Tester Pro Update Site Zip file to it's "runnable form"
3. Converts the Eclipse Test Framework Update Site Zip file to it's "runnable form"
4. Converts the Eclipse SDK Examples Update Site Zip file to it's "runnable form"
5. Deletes the directory "setup-eclipse" (to save disk space)

What does the build.xml script do?
-----------------------------------
1. Unpack Eclipse SDK to directory "eclipse-test"
2. Copy Window Tester Pro plugins and features to "eclipse-test"
3. Copy Eclipse Test Framework to "eclipse-test"
4. Patch library.xml (wrong path to JUNIT.XSL file)
5. Copy Eclipse SDK Examples to "eclipse-test"
6. Copy plugin that contains the UI tests to "eclipse-test"
7. Execute UI tests with Eclipse Test Framework
8. Generate a HTML JUnit report (in eclipse-test/report/html)


If you have any questions or comments regarding this example,
please ask them in the official WindowTester Google Group:
  http://groups.google.com/group/windowtester-pro