#!/bin/bash
#export JAVA_HOME=/usr/lib/jvm/java-6-sun
#export PATH=$JAVA_HOME\bin:$ANT_HOME\bin
ant -f build.xml -Dopsys=linux32
