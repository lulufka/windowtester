#!/bin/bash
ant -f setup.xml -Dopsys=linux32
